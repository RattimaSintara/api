#!/bin/bash
#export LANG=th_TH.UTF-8
uvicorn main:app --reload --loop asyncio --host 0.0.0.0 --port 3000 
# wait forever
while true; do
  sleep 3600
done
