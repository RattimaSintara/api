from fastapi import APIRouter
from typing import Optional
from fastapi.responses import JSONResponse
from .src.lang_extract import lx_extract
from .src.reference_verification import verify_reference
from .param import items
from datetime import datetime

router = APIRouter()
headers = {'Content-Type':'application/json','X-Content-Type-Options':'nosniff'}

@router.post("/extract")
def serviceExtract(jsonInput:items.InputItem):
    if jsonInput.text == None:
        res = {"status": -1,"result":"False"}
    print(jsonInput.text)
    res = lx_extract(jsonInput.text)
    return JSONResponse(content=res, headers=headers)

@router.post("/verify")
def serviceVerify(jsonInput:items.InputItem):
    if jsonInput.text == None:
        res = {"status": -1,"result":"False"}
    print(jsonInput.text)
    res = lx_extract(jsonInput.text)
    if res["status"] == 1:
        res = verify_reference(res["result"])
    return JSONResponse(content=res, headers=headers)
